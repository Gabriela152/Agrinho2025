let plantas = []; // Lista para guardar as plantas

function setup() {

  createCanvas(600, 400);

  // Criar a plantação (posição das plantas)

  for (let y = 310; y <= 380; y += 20) {

    for (let x = 20; x <= 280; x += 30) {

      plantas.push({ x: x, y: y, colhida: false }); // Cada planta tem x, y e se foi colhida

    }

  }

}

function draw() {

  background(135, 206, 235); // Céu azul

  // ----------- Campo -----------

  fill(34, 139, 34);

  rect(0, 300, 300, 100); // chão do campo

  // Plantação

  for (let planta of plantas) {

    if (!planta.colhida) { // Só desenha se não foi colhida

      fill(0, 128, 0);

      ellipse(planta.x, planta.y, 10, 20); // folhas

      fill(139, 69, 19);

      rect(planta.x - 2, planta.y + 5, 4, 10); // caule

    }

  }

  // Casinha no campo

  fill(210, 180, 140);

  rect(100, 220, 70, 80);

  fill(139, 69, 19);

  triangle(100, 220, 135, 180, 170, 220);

  // Sol

  fill(255, 223, 0);

  ellipse(100, 80, 60, 60);

  // ----------- Cidade -----------

  fill(169, 169, 169);

  rect(300, 300, 300, 100); // chão da cidade

  // Prédios

  fill(100);

  rect(400, 200, 50, 200);

  rect(470, 150, 50, 250);

  rect(540, 230, 40, 170);

  // Janelas dos prédios

  fill(255, 255, 0);

  rect(410, 220, 10, 20);

  rect(410, 250, 10, 20);

  rect(410, 280, 10, 20);

  rect(480, 170, 10, 20);

  rect(480, 200, 10, 20);

  rect(480, 230, 10, 20);

  rect(550, 250, 10, 20);

  rect(550, 280, 10, 20);

  rect(550, 310, 10, 20);

}

function mousePressed() {

  // Verifica se o clique foi em alguma planta

  for (let planta of plantas) {

    let d = dist(mouseX, mouseY, planta.x, planta.y);

    if (d < 15) { // Se clicou perto da planta

      planta.colhida = true; // Planta foi colhida

    }

  }function setup() {

  createCanvas(600, 400);

}

function draw() {

  background(135, 206, 235); // Céu azul

  // ----------- Campo -----------

  fill(34, 139, 34);

  rect(0, 300, 300, 100); // chão do campo

  // Plantação (fileiras de plantas)

  for (let y = 310; y <= 380; y += 20) {

    for (let x = 20; x <= 280; x += 30) {

      fill(0, 128, 0);

      ellipse(x, y, 10, 20); // planta (folhas)

      fill(139, 69, 19);

      rect(x - 2, y + 5, 4, 10); // caule

    }

  }

  // Casinha no campo

  fill(210, 180, 140);

  rect(100, 220, 70, 80);

  fill(139, 69, 19);

  triangle(100, 220, 135, 180, 170, 220);

  // Sol

  fill(255, 223, 0);

  ellipse(100, 80, 60, 60);

  // ----------- Cidade -----------

  fill(169, 169, 169);

  rect(300, 300, 300, 100); // chão da cidade

  // Prédios

  fill(100);

  rect(400, 200, 50, 200);

  rect(470, 150, 50, 250);

  rect(540, 230, 40, 170);

  // Janelas dos prédios

  fill(255, 255, 0);

  rect(410, 220, 10, 20);

  rect(410, 250, 10, 20);

  rect(410, 280, 10, 20);

  rect(480, 170, 10, 20);

  rect(480, 200, 10, 20);

  rect(480, 230, 10, 20);

  rect(550, 250, 10, 20);

  rect(550, 280, 10, 20);

  rect(550, 310, 10, 20);

}

}